# cpython-bin-deps
Binaries that the cpython build process depends on

It is currently expected that this will only be useful on Windows,
and in any case you should never need to clone this repository
unless you are updating its contents.
